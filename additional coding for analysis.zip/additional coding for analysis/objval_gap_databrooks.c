#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// ./exec file_10m file_60s output.txt

int main (int argc, char **argv){

    FILE *fin1, *fin2, *fout;


    if(argc != 4){
        printf("usage : <exec> <input1> <input2> <output.txt>\n");
        exit(-1);
    }
    fin1 = fopen(argv[1], "r");
    fin2 = fopen(argv[2], "r");
    fout = fopen(argv[3], "w");


    if(fin1 == NULL || fin1 == NULL  || fout == NULL ){

        printf ("erorr opening file(s).");
        exit(0);
    }

    float n, objval1=0.0, objval2=0.0;
    int nn, k=0;

    while( k <130){
        k++;
        fscanf(fin1, "%d\t%d\t%f\t%d\t%d\t%f\t%d\t\t%d\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f", &nn, &nn,  &n,  &nn,  &nn,  &n,  &nn,  &nn,  &n,  &objval1,  &n,  &n,  &n,  &n,  &n,  &n,  &n,  &n );
        fscanf(fin2, "%d\t%d\t%f\t%d\t%d\t%f\t%d\t\t%d\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f%f",   &nn, &nn,  &n,  &nn,  &nn,  &n,  &nn,  &nn,  &n,  &objval2,  &n,  &n,  &n,  &n,  &n,  &n,  &n,  &n ) ;
        printf("\n%f, %f", objval1, objval2);
        fprintf(fout, "\n %f", fabs((objval1 - objval2)/objval1));
    }

}