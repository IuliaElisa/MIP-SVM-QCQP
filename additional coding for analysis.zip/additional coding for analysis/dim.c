#include <stdio.h>
#include<stdlib.h>

int main (){

    FILE *fin = fopen("Compas_ext1.txt", "r"),  *fout = fopen("out_dim.txt", "w");
    int state = 0, c,k=0;


    while((c=fgetc(fin)) != '\n'){
        //printf("%c", c);
        if((c >='0' && c<='9') || c=='-' || c == '.'){
            state=1;
        }
        else{
            if(state ==1 ){
            k++;
            state=0;
            fprintf(fout, "1        ");
            }
        }
    }

    printf("%d", k);
}