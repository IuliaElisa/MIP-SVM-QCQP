#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
int main (int argc, char *argv[]){

    FILE *fin, *fout;

    int k=1;
    if(argc != 2){
        printf("usage: <exe> <file.txt>");
        exit(0);
    }


    fin = fopen (argv[1], "r");
    fout = fopen("status.txt", "w");
    if(fin == NULL){
        printf("Error opening input file.");
        exit(0);
    }
    
    if(fout == NULL){
        printf("Error opening input file.");
        exit(0);
    }

    int state = 0;
    int c;
    c = getc(fin);
    int n=0;

    while(c != EOF){

        if (c == 'm' && ((c=fgetc(fin)) == 'i') && ((c=fgetc(fin))) == 'n'){
            c = fgetc(fin);
            c = fgetc(fin);
            c = fgetc(fin);
            if(c !='S'){
            state = 0;

            fprintf(fout, "nan\n");
            n = 0;
            }
        }

        if(c == 'U' && state == 0){ // from STATUS nb
            state = 1;
        }

        if((state == 1 || state == 2) && isnumber(c)){
            state = 2;
            n = n*10+c-'0';
        }

        if(state == 2 && (!isnumber(c)) && c !='U'){
            state = 0;
            
            printf( "%d %d\n",k, n);
            fprintf(fout, "%d\n",n);
            n = 0;
            k++;
        }

        c = getc(fin);

    }


}